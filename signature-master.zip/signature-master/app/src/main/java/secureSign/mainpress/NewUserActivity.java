package secureSign.mainpress;

import java.io.File;
import java.io.IOException;

import secureSign.mainpress.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class NewUserActivity extends Activity {

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
		setContentView(R.layout.newuser);
		
    	final Activity parentActivity = this;
        final Button buttonok = (Button) findViewById(R.id.buttonok);
        
        buttonok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click OK
            	
            	final EditText edittext = (EditText) findViewById(R.id.editTextname);
				String name = edittext.getText().toString();
				//v�rifier si ce nom existe???
				if ((!name.isEmpty()) && (Singleton.getInstance().iden.getCode(name) == null)){
					Singleton.getInstance().iden.addIdentity(name);
					try {
						Singleton.getInstance().iden.saveIdentities();
					} catch (IOException e) {
						// Auto-generated catch block
						e.printStackTrace();
					}
					Singleton.getInstance().actualCode = new String(Singleton.getInstance().iden.getCode(name));
					//cr�er les r�pertoires... pour sauvegarder les signatures (originales et extraites)
					String dirName = parentActivity.getBaseContext().getDir("main", Context.MODE_WORLD_READABLE).getAbsolutePath();
					dirName += "/database/";
					dirName += Singleton.getInstance().iden.getCode(name);

					(new File(dirName)).mkdirs();

					Singleton.getInstance().captureReason = SecureSignActivity.CR_TRAIN;
					Singleton.getInstance().trainBaseIndex= 1;
	        		Intent intent = new Intent(parentActivity, TrainingActivity.class);
	        		startActivity(intent);
	        		
	        		finish();
	        	}else{ // IDNO
	        		showDialog(0);
				}
            }});
        
        final Button buttoncancel = (Button) findViewById(R.id.buttoncancel);
        
        buttoncancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click cancel
        		finish();
            }});
    }
    
	@Override 
	protected Dialog onCreateDialog(int id) { 
    AlertDialog alertDialog = null; 

	AlertDialog.Builder builder;
	LayoutInflater inflater;
	View layout;
	switch (id) {
       
    case 0: 
    	inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
    	layout = inflater.inflate(R.layout.rejeteddialog,
    	                               (ViewGroup) findViewById(R.id.layout_root));

    	TextView text2 = (TextView) layout.findViewById(R.id.label);
    	text2.setText("Please try another user name!\nUser name exists or not valid!");
    	builder = new AlertDialog.Builder(this);
    	builder.setView(layout);
    	builder
        .setCancelable(true)
        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                 dialog.cancel();
			        }
        });
    	alertDialog = builder.create();
    	
    	alertDialog.show();
    	alertDialog.setCancelable(false);
    	break; 
	} 
    return alertDialog; 
  }

}
