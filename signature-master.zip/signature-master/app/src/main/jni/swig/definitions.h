#ifndef definitions_
#define definitions_

#ifndef NULL
#define NULL					0
#endif

#define X_STANDARD_VAR			100		//pour normaliser la taille des signatures
#define PI						3.14159265358979323846
#define MAX_DOUBLE				1e300
#define MIN_DOUBLE				-1e300

#endif

